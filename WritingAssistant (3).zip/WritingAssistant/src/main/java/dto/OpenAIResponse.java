package dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

/**
 * Data Transfer Object (DTO) for the top-level OpenAI Chat Completion API response.
 * Enforces Encapsulation by using private fields and public getters.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class OpenAIResponse {

    // 1. FIX: Make the field private (Encapsulation)
    private List<Choice> choices;

    // FIX: Provide the public getter required by APIService.java
    public List<Choice> getChoices() {
        return choices;
    }

    /**
     * Maps the 'choices' array from the API response.
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Choice {
        // 2. FIX: Make the field private (Encapsulation)
        private Message message;

        // FIX: Provide the public getter required by APIService.java
        public Message getMessage() {
            return message;
        }
    }

    /**
     * Maps the 'message' object inside 'choice' to extract the content.
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Message {
        // 3. FIX: Make fields private (Encapsulation)
        private String role;
        private String content;

        // FIX: Provide the public getter required by APIService.java
        public String getContent() {
            return content;
        }

        // You may also want a getter for role, but getContent is the critical fix.
        public String getRole() {
            return role;
        }
    }
}