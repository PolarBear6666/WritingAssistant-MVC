package org.example;

import controller.MainController;
import model.Config; // Import Config to force initialization and error checking
import view.MainFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {

        // 1. Perform initial configuration check before launching the UI.
        // The Config singleton will attempt to load config file and essential properties (like API_KEY).
        try {
            Config.getInstance(); // This forces initialization and checks for API Key/config file presence.
        } catch (RuntimeException e) {
            JOptionPane.showMessageDialog(null,
                    "FATAL CONFIGURATION ERROR: " + e.getMessage(),
                    "Configuration Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 2. Start the Swing UI on the Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            try {
                // 3. Instantiate MVC components

                // FIX: The controller is now initialized with NO ARGUMENTS,
                // as it uses the APIClient Singleton internally.
                MainController controller = new MainController();

                // The view is created next, receiving the controller for delegation
                MainFrame view = new MainFrame(controller);

                // The controller needs a reference back to the view to update it
                controller.setView(view);

                view.setVisible(true);
            } catch (Exception e) {
                // Catch any runtime errors during controller/view setup (e.g., failed config load, etc.)
                JOptionPane.showMessageDialog(null,
                        "Application failed to start: " + e.getMessage(),
                        "Fatal Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        });
    }
}