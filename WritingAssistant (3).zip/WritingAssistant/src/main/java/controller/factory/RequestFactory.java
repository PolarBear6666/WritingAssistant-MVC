package controller.factory;

import com.fasterxml.jackson.databind.ObjectMapper;
import dto.OpenAIRequest;
import dto.OpenAIRequest.Message; // Inner class for messages
import model.Config;
import model.strategy.GenerationStrategy;

import java.util.List;

/**
 * Implements the Factory Design Pattern.
 * Responsible for creating the complex OpenAIRequest DTO object based on
 * the selected GenerationStrategy and the user input.
 */
public class RequestFactory {

    // Uses the configuration for the model name
    private static final String MODEL_NAME = Config.getInstance().getProperty("API_MODEL");
    private final ObjectMapper objectMapper = new ObjectMapper(); // Used for final JSON serialization

    /**
     * Constructs the OpenAIRequest DTO and serializes it to a JSON String.
     * @param prompt The user's input text.
     * @param strategy The selected writing mode (Strategy Pattern).
     * @return The API request body as a JSON String, ready for network transmission.
     * @throws Exception if JSON serialization fails.
     */
    public String createJsonRequest(String prompt, GenerationStrategy strategy) throws Exception {

        // 1. Build the list of Message DTOs
        List<Message> messages = List.of(
                // Use the strategy's system prompt
                new Message("system", strategy.getSystemPrompt()),
                // Use the user's input
                new Message("user", prompt)
        );

        // 2. Create the Request DTO
        OpenAIRequest requestBody = new OpenAIRequest(
                MODEL_NAME,
                messages,
                // Use the strategy's max token value
                strategy.getMaxTokens()
        );

        // 3. Convert the DTO to a JSON String
        String jsonBody = objectMapper.writeValueAsString(requestBody);

        return jsonBody;
    }
}