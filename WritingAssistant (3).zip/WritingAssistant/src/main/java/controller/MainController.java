package controller;

import service.APIService;
import controller.factory.RequestFactory;
import model.domain.WritingSession;
import model.strategy.GenerationStrategy; // Interface used here (Correct)
import model.strategy.CreativeStorytellingStrategy; // Concrete Strategy used for default (Correct)
import model.repository.SessionRepository;
import model.repository.ObjectStreamSessionRepository;
import view.MainFrame;
import view.GenerationStatusListener;

import javax.swing.SwingUtilities;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CancellationException; // FIX: Import CancellationException for cleaner check

/**
 * The Controller in the MVC pattern. Handles user actions, communicates
 * with the Service and Repository layers, and updates the View.
 * Implements the Observable part of the Observer Pattern.
 */
public class MainController {

    private MainFrame view;

    // Dependencies on Service and Factory Layers
    private final APIService apiService;
    private final RequestFactory requestFactory;
    private final SessionRepository sessionRepository;

    // List of Observers (Listeners) for the Observer Pattern
    private final List<GenerationStatusListener> listeners = new ArrayList<>();

    // Field to hold the active asynchronous task (for cancellation)
    private CompletableFuture<String> currentGenerationTask;

    // FIX: Ensure this is the GenerationStrategy interface
    private GenerationStrategy currentStrategy;
    private WritingSession session = new WritingSession();

    /**
     * Constructor for the MainController. Initializes all dependencies.
     */
    public MainController() {
        this.apiService = new APIService();
        this.requestFactory = new RequestFactory();
        this.sessionRepository = new ObjectStreamSessionRepository();
        this.currentStrategy = new CreativeStorytellingStrategy();
    }

    // --- OBSERVER PATTERN (Observable Management) ---

    public void setView(MainFrame view) {
        this.view = view;
        if (view != null) {
            addStatusListener(view);
            view.setStatus("Ready. Strategy: " + currentStrategy.getName());
        }
    }

    public void addStatusListener(GenerationStatusListener listener) {
        this.listeners.add(listener);
    }

    private void notifyGenerationStarted() {
        listeners.forEach(GenerationStatusListener::generationStarted);
    }

    private void notifyGenerationCompleted(String result) {
        listeners.forEach(l -> l.generationCompleted(result));
    }

    private void notifyGenerationFailed(String errorMessage) {
        listeners.forEach(l -> l.generationFailed(errorMessage));
    }

    // --- CORE LOGIC ---

    public void generateText(String userInput) {
        if (userInput.trim().isEmpty()) return;

        notifyGenerationStarted();

        try {
            // 1. FACTORY PATTERN: Use the factory to create the JSON request body
            String jsonRequest = requestFactory.createJsonRequest(userInput, currentStrategy);

            // 2. SERVICE CALL: Call the asynchronous service method
            CompletableFuture<String> future = apiService.generateTextAsync(jsonRequest);

            // 3. CANCELLATION: Store the future to allow cancellation later
            this.currentGenerationTask = future;

            // 4. ASYNC HANDLING: Handle the result and errors
            future.thenAccept(result -> {
                        SwingUtilities.invokeLater(() -> {
                            session.addExchange(userInput, result); // Update Model
                            notifyGenerationCompleted(result);
                        });
                    })
                    .exceptionally(e -> {
                        // Handle exceptions from the async chain
                        String errorMessage = (e.getCause() != null && e.getCause().getMessage() != null)
                                ? e.getCause().getMessage()
                                : "Generation task failed.";

                        SwingUtilities.invokeLater(() -> {
                            // FIX: Use the imported CancellationException for cleaner check
                            if (e.getCause() instanceof CancellationException) {
                                notifyGenerationFailed("Process Canceled by User.");
                            } else {
                                notifyGenerationFailed("FAILED: " + errorMessage);
                            }
                        });
                        return null;
                    });

        } catch (Exception e) {
            notifyGenerationFailed("SETUP ERROR: " + e.getMessage());
        }
    }

    public void cancelGeneration() {
        if (currentGenerationTask != null && !currentGenerationTask.isDone()) {
            // Call cancel(true) to interrupt the underlying thread if possible
            boolean success = currentGenerationTask.cancel(true);

            if (success) {
                // IMPORTANT: The view.setStatus call must be delegated back to the view via the listener
                notifyGenerationFailed("Cancellation requested...");
            } else {
                // If cancellation fails (already completed), notify the view
                notifyGenerationFailed("Task already completed or cancellation failed.");
            }
        }
    }

    public void setStrategy(GenerationStrategy newStrategy) {
        this.currentStrategy = newStrategy;
        if (view != null) {
            view.setStatus("Strategy switched to: " + newStrategy.getName());
        }
    }

    public GenerationStrategy getCurrentStrategy() {
        return currentStrategy;
    }

    // --- REPOSITORY PATTERN METHODS (Step 8) ---

    public void saveSession() {
        File fileToSave = promptForFile(true);

        if (fileToSave != null) {
            try {
                sessionRepository.save(session, fileToSave);
                view.setStatus("Session saved successfully to: " + fileToSave.getAbsolutePath());
            } catch (IOException ex) {
                view.setStatus("ERROR: Could not save session.");
                JOptionPane.showMessageDialog(view, "Error saving session: " + ex.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void loadSession() {
        File fileToLoad = promptForFile(false);

        if (fileToLoad != null) {
            try {
                this.session = sessionRepository.load(fileToLoad);

                if (!session.getExchanges().isEmpty()) {
                    WritingSession.Exchange lastExchange = session.getLastExchange();
                    view.setInputText(lastExchange.getInput());
                    view.setResultText(lastExchange.getOutput());
                } else {
                    view.setInputText("");
                    view.setResultText("");
                }
                view.setStatus("Session loaded successfully from: " + fileToLoad.getAbsolutePath());
            } catch (IOException | ClassNotFoundException ex) {
                view.setStatus("ERROR: Could not load session.");
                JOptionPane.showMessageDialog(view, "Error loading session: " + ex.getMessage(), "Load Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private File promptForFile(boolean isSaving) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(isSaving ? "Save Writing Session" : "Load Writing Session");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Writing Session Files (*.session)", "session");
        fileChooser.setFileFilter(filter);

        int userSelection = isSaving ? fileChooser.showSaveDialog(view) : fileChooser.showOpenDialog(view);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            if (isSaving && !selectedFile.getName().toLowerCase().endsWith(".session")) {
                return new File(selectedFile.getAbsolutePath() + ".session");
            }
            return selectedFile;
        }
        return null;
    }
}