package model.repository;

import model.domain.WritingSession;
import java.io.*;

/**
 * Concrete implementation of the SessionRepository using Java's Object Serialization (Object Streams).
 * This class hides the implementation details from the Controller.
 */
public class ObjectStreamSessionRepository implements SessionRepository {

    /**
     * Uses ObjectOutputStream to write the session object to a file.
     */
    @Override
    public void save(WritingSession session, File file) throws IOException {
        // The implementation detail is encapsulated here
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(session);
        }
    }

    /**
     * Uses ObjectInputStream to read and deserialize the session object from a file.
     */
    @Override
    public WritingSession load(File file) throws IOException, ClassNotFoundException {
        // The implementation detail is encapsulated here
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (WritingSession) ois.readObject();
        }
    }
}