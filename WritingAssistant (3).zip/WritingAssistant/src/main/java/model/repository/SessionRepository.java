package model.repository;

import model.domain.WritingSession;
import java.io.File;
import java.io.IOException;

/**
 * Interface defining the contract for session persistence.
 * This fulfills the Abstraction OOP pillar requirement.
 */
public interface SessionRepository {

    /**
     * Saves the current WritingSession model to a specified location.
     * @param session The WritingSession object to save.
     * @param file The target file location.
     * @throws IOException If a file operation fails.
     */
    void save(WritingSession session, File file) throws IOException;

    /**
     * Loads a WritingSession model from a specified location.
     * @param file The source file location.
     * @return The loaded WritingSession object.
     * @throws IOException If a file operation fails.
     * @throws ClassNotFoundException If the serialized object class is not found.
     */
    WritingSession load(File file) throws IOException, ClassNotFoundException;
}