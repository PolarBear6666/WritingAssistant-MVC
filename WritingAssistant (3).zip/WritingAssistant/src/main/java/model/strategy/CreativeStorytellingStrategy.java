package model.strategy;

/**
 * Concrete strategy for creative, imaginative text generation.
 */
public class CreativeStorytellingStrategy extends AbstractStrategy {

    @Override
    public String getName() {
        return "Creative Storytelling";
    }

    @Override
    public String getSystemPrompt() {
        return "You are an award-winning fantasy author. Your responses must be descriptive, imaginative, and focused on narrative flow. Do not use bullet points or lists.";
    }

    // Optional: Override max tokens for longer creative responses
    @Override
    public int getMaxTokens() {
        return 2048; // Increased this from 800 to 2048 for better storytelling potential
    }

    /**
     * FIX: Implement the required unique strategy identifier from GenerationStrategy.
     */
    @Override
    public String getStrategyId() {
        return "creative_storytelling";
    }
}