package model.strategy;

/**
 * Abstract base class for all concrete writing strategies.
 * Fulfills the Inheritance requirement.
 */
public abstract class AbstractStrategy implements GenerationStrategy {

    // Common implementation for the system prompt retrieval.
    // The concrete classes only need to define the specific prompt.
    @Override
    public abstract String getSystemPrompt();

    // Common implementation for max tokens. All modes use a default,
    // but they can be overridden in the concrete class.
    @Override
    public int getMaxTokens() {
        return 500; // Default token limit
    }

    // Must override the getName method in concrete classes
    @Override
    public abstract String getName();

    // Fulfills the Polymorphism/Override requirement: providing a default implementation
    // of toString that includes the mode's name.
    @Override
    public String toString() {
        return getName();
    }
}