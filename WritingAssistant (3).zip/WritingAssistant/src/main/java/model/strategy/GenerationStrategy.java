package model.strategy;

/**
 * Interface defining the contract for all writing modes.
 * This is the 'Strategy' interface in the Strategy Design Pattern,
 * allowing for polymorphic execution and fulfilling the Abstraction/Inheritance pillars.
 */
public interface GenerationStrategy {

    /**
     * The user-friendly name displayed in the UI dropdown.
     * @return The display name.
     */
    String getName();

    /**
     * FIX: Added a unique identifier for the strategy.
     * This enhances Polymorphism and is useful for persistence (saving/loading the active strategy).
     * @return A unique, stable string ID for the strategy (e.g., "creative_story").
     */
    String getStrategyId();

    /**
     * The hidden instruction given to the AI to set its tone or role.
     * @return The system prompt string.
     */
    String getSystemPrompt();

    /**
     * The maximum number of tokens the AI is allowed to generate.
     * @return The token limit.
     */
    int getMaxTokens();
}