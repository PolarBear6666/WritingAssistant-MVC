package model.strategy;

/**
 * Concrete strategy for formal, research-focused text generation.
 * Implements the required methods from the GenerationStrategy interface.
 */
public class FormalAcademicStrategy implements GenerationStrategy { // NOTE: Changed to implement GenerationStrategy directly as AbstractStrategy was not provided.

    // --- Core Strategy Implementations ---

    @Override
    public String getName() {
        return "Formal Academic Report";
    }

    @Override
    public String getSystemPrompt() {
        return "You are a professional research assistant. Your responses must be objective, well-structured using paragraphs and subheadings, and maintain a formal, objective tone.";
    }

    // --- FIX 1: Implement required getStrategyId() (from Step 14) ---
    @Override
    public String getStrategyId() {
        return "formal_academic"; // Unique, stable ID for this strategy
    }

    // --- FIX 2: Implement required getMaxTokens() ---
    @Override
    public int getMaxTokens() {
        // Formal reports often need more space for structure and detail
        return 1024;
    }
}