package model;

import java.net.http.HttpClient;
import java.time.Duration; // Import Duration

/**
 * Singleton class responsible for initializing and holding shared API resources,
 * specifically the HttpClient and API Key.
 * Fulfills the Singleton Design Pattern (Required).
 * Also enforces the API Timeout requirement (Step 13).
 */
public class APIClient {
    private static APIClient instance;
    private final HttpClient httpClient;
    private final String apiKey;

    // Config parameters for API Timeout
    private static final String API_TIMEOUT_KEY = "API_TIMEOUT_SECONDS";
    private static final int DEFAULT_API_TIMEOUT = 30; // 30 seconds default

    /**
     * Private constructor to prevent direct instantiation.
     */
    private APIClient() {
        Config config = Config.getInstance();

        // 1. Retrieve API Key from Config (Assuming the key is stored as "API_KEY")
        // FIX: The key should be retrieved from Config for a unified source of truth
        this.apiKey = config.getProperty("API_KEY");
        if (this.apiKey == null || this.apiKey.isEmpty()) {
            throw new RuntimeException("API Key (API_KEY) not found in configuration file.");
        }

        // 2. Get Timeout Value (Using the safe method from corrected Config)
        // FIX: Use API_TIMEOUT_SECONDS and a default value
        int timeoutSeconds = config.getIntProperty(API_TIMEOUT_KEY, DEFAULT_API_TIMEOUT);

        // 3. Build the HttpClient with configured Timeout (CRITICAL FIX)
        this.httpClient = HttpClient.newBuilder()
                // Use Duration.ofSeconds for better resilience and alignment with config
                .connectTimeout(Duration.ofSeconds(timeoutSeconds))
                .build();

        System.out.println("APIClient initialized. Timeout set to: " + timeoutSeconds + " seconds.");
    }

    /**
     * Provides the global access point to the single instance of APIClient (Singleton Pattern).
     * This method is thread-safe (synchronized).
     * @return The single instance of APIClient.
     */
    public static synchronized APIClient getInstance() {
        if (instance == null) {
            instance = new APIClient();
        }
        return instance;
    }

    /**
     * Getter for the configured HttpClient instance.
     */
    public HttpClient getHttpClient() {
        return httpClient;
    }

    /**
     * Getter for the securely retrieved API key.
     */
    public String getApiKey() {
        return apiKey;
    }
}