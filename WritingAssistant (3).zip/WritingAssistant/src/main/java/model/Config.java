package model;

import java.io.InputStream;
import java.util.Properties;

/**
 * Singleton class responsible for loading and providing access to application configuration properties.
 * Fulfills the Singleton Design Pattern requirement.
 */
public class Config {
    // FIX: Use the actual properties file name (typically config.properties)
    private static final String CONFIG_FILE = "config.properties";
    private static Config instance;

    private final Properties properties = new Properties();

    private Config() {
        // Use try-with-resources for reliable stream closing
        try (InputStream input = getClass().getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            if (input == null) {
                // IMPORTANT: In production, switch to config.properties. For development, allow example
                // If config.properties is not found, try the example version
                try (InputStream exampleInput = getClass().getClassLoader().getResourceAsStream("config.properties.example")) {
                    if (exampleInput == null) {
                        throw new RuntimeException("Configuration file not found: " + CONFIG_FILE + " or config.properties.example");
                    }
                    properties.load(exampleInput);
                    System.err.println("WARNING: Loaded properties from config.properties.example.");
                }
            } else {
                properties.load(input);
            }
        } catch (Exception e) {
            // Log the error and fail application startup
            throw new RuntimeException("CRITICAL: Failed to load configuration properties.", e);
        }
    }

    /**
     * Provides the single global instance of the Configuration manager (Singleton Pattern).
     */
    public static synchronized Config getInstance() {
        if (instance == null) {
            instance = new Config();
        }
        return instance;
    }

    /**
     * Retrieves a property value as a String.
     */
    public String getProperty(String key) {
        return properties.getProperty(key);
    }

    /**
     * FIX: Added method to retrieve an integer property with a safe default value.
     * This makes reading API_TIMEOUT_SECONDS, MAX_RETRIES, etc., more robust.
     */
    public int getIntProperty(String key, int defaultValue) {
        String value = properties.getProperty(key);
        if (value == null) {
            System.err.println("Warning: Config key '" + key + "' not found. Using default: " + defaultValue);
            return defaultValue;
        }
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            System.err.println("Error: Config value for '" + key + "' is not an integer. Using default: " + defaultValue);
            return defaultValue;
        }
    }
}