package model;

/**
 * Defines the interface for different AI writing behaviors (modes/strategies).
 * This is the Strategy interface in the Strategy Design Pattern.
 */
public interface WritingStrategy {

    /**
     * Gets the system prompt used to instruct the AI model on its role and tone.
     * @return The instructional prompt string sent to the OpenAI API.
     */
    String getSystemPrompt();

    /**
     * Gets a friendly, displayable name for the UI (JComboBox).
     * @return The name of the strategy.
     */
    String getName();

    /**
     * Gets the maximum number of tokens the AI should generate (for cost control).
     * @return The max_tokens limit.
     */
    int getMaxTokens();
}