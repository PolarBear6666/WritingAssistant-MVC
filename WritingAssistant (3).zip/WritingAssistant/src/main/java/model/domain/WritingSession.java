package model.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * The core Model object in the MVC pattern. Represents a single conversation session.
 * Fulfills the Encapsulation OOP pillar by controlling access and ensuring immutability.
 */
public class WritingSession implements Serializable {
    private static final long serialVersionUID = 1L;

    // Encapsulation: Field is private and final, enforcing controlled access
    private final List<Exchange> exchanges;
    private String title = "New Session";

    public WritingSession() {
        // Initialize the internal mutable list
        this.exchanges = new ArrayList<>();
    }

    /**
     * Inner class representing a single, immutable exchange (input/output pair).
     * Fulfills Encapsulation by making fields final.
     */
    public static class Exchange implements Serializable {
        private static final long serialVersionUID = 1L;

        // FIX: Fields are now private and FINAL for immutability (Encapsulation)
        private final String input;
        private final String output;

        public Exchange(String input, String output) {
            this.input = input;
            this.output = output;
        }

        // Only public getters provided (read-only access)
        public String getInput() { return input; }
        public String getOutput() { return output; }

        // FIX: Added required Polymorphism overrides for equals() and hashCode()
        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Exchange exchange = (Exchange) o;
            return Objects.equals(input, exchange.input) && Objects.equals(output, exchange.output);
        }

        @Override
        public int hashCode() {
            return Objects.hash(input, output);
        }

        // FIX: Improved toString() for cleaner logging/debugging (Polymorphism)
        @Override
        public String toString() {
            return "Exchange{input length=" + input.length() + ", output length=" + output.length() + "}";
        }
    }

    /**
     * Controlled method to add a new exchange to the session.
     */
    public void addExchange(String input, String output) {
        exchanges.add(new Exchange(input, output));
    }

    /**
     * Provides an immutable, read-only view of the exchanges list.
     * This prevents external layers from directly modifying the list (Encapsulation).
     */
    public List<Exchange> getExchanges() {
        return Collections.unmodifiableList(exchanges);
    }

    public Exchange getLastExchange() {
        if (exchanges.isEmpty()) {
            return null;
        }
        return exchanges.get(exchanges.size() - 1);
    }

    // Title is mutable, but access is controlled via getters/setters (Encapsulation)
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    // FIX: Added required Polymorphism overrides for equals() and hashCode()
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WritingSession that = (WritingSession) o;
        return Objects.equals(exchanges, that.exchanges) && Objects.equals(title, that.title);
    }

    @Override
    public int hashCode() {
        return Objects.hash(exchanges, title);
    }

    // FIX: Improved toString() (Polymorphism)
    @Override
    public String toString() {
        return "WritingSession [Title: " + title + ", Exchanges: " + exchanges.size() + "]";
    }
}