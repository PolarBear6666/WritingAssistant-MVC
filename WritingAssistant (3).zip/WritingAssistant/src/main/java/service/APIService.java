package service;

import model.APIClient;
import model.Config;
import dto.OpenAIResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

/**
 * Handles all business logic related to API communication, including Retries and Backoff.
 * This class uses the APIClient for network setup and focuses on Resilience and Parsing.
 */
public class APIService {

    private final HttpClient httpClient;
    private final String apiKey;
    private final String apiUrl;
    private final ObjectMapper objectMapper;

    // Resiliency Configuration (Read from Config)
    private final int maxRetries;
    private final long initialBackoffDelay;

    public APIService() {
        APIClient client = APIClient.getInstance();
        this.httpClient = client.getHttpClient();
        this.apiKey = client.getApiKey();

        Config config = Config.getInstance();
        this.apiUrl = config.getProperty("API_BASE_URL");

        // --- FIX BEGIN: Use local variables for single assignment of final fields ---
        int tempMaxRetries;
        long tempInitialBackoffDelay;

        try {
            tempMaxRetries = Integer.parseInt(config.getProperty("MAX_RETRIES"));
            tempInitialBackoffDelay = Long.parseLong(config.getProperty("BACKOFF_DELAY_MS"));
        } catch (NumberFormatException e) {
            System.err.println("Warning: Resiliency config missing or invalid. Using defaults.");
            // ASSIGN DEFAULT VALUES TO LOCAL VARIABLES
            tempMaxRetries = 3;
            tempInitialBackoffDelay = 500L;
        }

        // FINAL ASSIGNMENT: Assign final class fields exactly once outside the try-catch
        this.maxRetries = tempMaxRetries;
        this.initialBackoffDelay = tempInitialBackoffDelay;
        // --- FIX END ---

        this.objectMapper = new ObjectMapper()
                .setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
    }

    /**
     * Sends an asynchronous request to the OpenAI API, wrapped in the retry logic.
     * @param jsonBody The fully built JSON request body.
     * @return A CompletableFuture<String> containing the generated text or an error message.
     */
    public CompletableFuture<String> generateTextAsync(String jsonBody) {
        // Start the retry mechanism from attempt 0
        CompletableFuture<HttpResponse<String>> rawResponseFuture = executeWithRetry(() -> sendRequest(jsonBody), 0);

        // Chain the parsing and final error handling after retries are exhausted
        return rawResponseFuture
                .thenApply(this::handleResponse) // Pass successful raw response to handler
                .exceptionally(e -> {
                    // Final Error Handling for exceptions that survived retries
                    String message = e.getCause() != null ? e.getCause().getMessage() : e.getMessage();
                    System.err.println("Permanent API Error: " + message);
                    return "API Request Failed Permanently: " + message;
                });
    }

    /**
     * Executes the raw API request and returns a CompletableFuture<HttpResponse<String>>.
     */
    private CompletableFuture<HttpResponse<String>> sendRequest(String jsonBody) {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(apiUrl))
                    .header("Authorization", "Bearer " + apiKey)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                    .build();

            // Returns the raw HttpResponse future
            return httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString());

        } catch (Exception e) {
            // Catches synchronous errors (e.g., malformed URI, JSON serialization failure)
            return CompletableFuture.failedFuture(e);
        }
    }

    /**
     * Recursive function to handle the retry mechanism with exponential backoff.
     * Fulfills the Resiliency requirement.
     */
    private CompletableFuture<HttpResponse<String>> executeWithRetry(
            Supplier<CompletableFuture<HttpResponse<String>>> task, int attempt) {

        return task.get().handle((response, error) -> {

            // If there's an error OR a transient status code
            if (error != null || (response != null && isRetryableStatusCode(response.statusCode()))) {

                if (attempt < maxRetries) {
                    // Calculate exponential backoff delay (e.g., 500ms, 1000ms, 2000ms...)
                    // The delay grows by a power of 2 for each attempt (2^0, 2^1, 2^2...)
                    long delay = initialBackoffDelay * (1L << attempt);

                    System.err.println("API Request failed on attempt " + (attempt + 1) +
                            ". Retrying in " + delay + "ms. Error: " + (error != null ? error.getMessage() : "HTTP Status " + response.statusCode()));
                    //

                    // Schedule the next retry using a delayed executor
                    return CompletableFuture.supplyAsync(() -> executeWithRetry(task, attempt + 1),
                                    CompletableFuture.delayedExecutor(delay, TimeUnit.MILLISECONDS))
                            .thenCompose(f -> f); // Flattens the future result
                } else {
                    // Maximum retries reached, fail permanently
                    System.err.println("API Request failed after " + maxRetries + " retries. Final attempt failed.");

                    // Propagate the final exception/error status up the chain
                    Throwable finalError = error != null ? error : new RuntimeException("Final HTTP Status: " + response.statusCode());
                    return CompletableFuture.<HttpResponse<String>>failedFuture(finalError);
                }
            } else {
                // Success (no retryable error)
                return CompletableFuture.completedFuture(response);
            }
        }).thenCompose(f -> f); // Flatten the CompletableFuture<CompletableFuture<...>> structure
    }

    /**
     * Checks if an HTTP status code indicates a transient error that should be retried.
     */
    private boolean isRetryableStatusCode(int statusCode) {
        // Standard transient errors: 429 (Rate Limit), 500 (Internal Server Error), 502, 503, 504
        return statusCode == 429 || (statusCode >= 500 && statusCode <= 599);
    }

    // --- Response Parsing and Content Extraction ---

    /**
     * Handles the successful HTTP response, checks for non-retryable errors, and parses the JSON body.
     */
    private String handleResponse(HttpResponse<String> response) {
        // After retries, if we still get a non-200 non-retryable code (like 401, 404, 400), it's a permanent error.
        if (response.statusCode() != 200) {
            System.err.println("API Permanent Error Response: " + response.body());
            throw new RuntimeException("API Request Failed Permanently with Status " + response.statusCode() +
                    ". Check console for bad key or request format.");
        }

        // 2. Parse the JSON response
        try {
            OpenAIResponse apiResponse = objectMapper.readValue(response.body(), OpenAIResponse.class);

            // 3. Safely extract the content
            if (apiResponse.getChoices() != null && !apiResponse.getChoices().isEmpty()) {
                return apiResponse.getChoices().get(0).getMessage().getContent();
            }

            throw new RuntimeException("API response was successful but contained no generated text content.");

        } catch (Exception e) {
            // Error Handling: Catch JSON parsing issues
            throw new RuntimeException("Failed to parse API response: " + e.getMessage());
        }
    }

    /**
     * Parses the raw JSON response from the API into the domain's result format (For use cases like tests/mocks).
     */
    public String parseResponse(String jsonResponse) throws Exception {
        // NOTE: Simplified parsing for mock/test purposes.

        OpenAIResponse apiResponse = objectMapper.readValue(jsonResponse, OpenAIResponse.class);

        if (apiResponse.getChoices() != null && !apiResponse.getChoices().isEmpty()) {
            return apiResponse.getChoices().get(0).getMessage().getContent();
        }
        throw new RuntimeException("Failed to parse mock JSON content.");
    }
}