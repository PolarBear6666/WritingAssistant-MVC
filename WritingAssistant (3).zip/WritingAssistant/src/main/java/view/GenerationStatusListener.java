package view;

/**
 * The Observer Interface in the Observer Pattern.
 * Any class that wants to be notified of the API generation status must implement this.
 */
public interface GenerationStatusListener {

    /**
     * Called when the generation process is initiated.
     * Use to disable input fields and show a spinner.
     */
    void generationStarted();

    /**
     * Called when the generation process successfully returns a result.
     * @param result The generated text.
     */
    void generationCompleted(String result);

    /**
     * Called when the generation process fails due to an API or network error.
     * @param errorMessage A user-friendly message describing the failure.
     */
    void generationFailed(String errorMessage);
}