package view;

import controller.MainController;
import model.strategy.GenerationStrategy; // Interface used here
import model.strategy.CreativeStorytellingStrategy;
import model.strategy.FormalAcademicStrategy;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * The View in the MVC pattern. Handles displaying data and capturing user input.
 * It implements the GenerationStatusListener interface to act as the Observer (Step 10).
 *
 */
public class MainFrame extends JFrame implements GenerationStatusListener {

    private final MainController controller;
    private final JTextArea inputArea = new JTextArea(10, 45);
    private final JTextArea resultArea = new JTextArea(10, 45);
    private final JLabel statusLabel = new JLabel("Application Starting...");
    private final JComboBox<GenerationStrategy> strategySelector;

    // UI Components for Control
    private final JButton generateButton = new JButton("Generate Text");
    private final JButton cancelButton = new JButton("Stop Generation"); // Cancel Button

    // All available strategies
    private final List<GenerationStrategy> availableStrategies = List.of(
            new CreativeStorytellingStrategy(),
            new FormalAcademicStrategy()
    );

    public MainFrame(MainController controller) {
        this.controller = controller;

        setTitle("AI Writing Assistant (MVC + Strategy + Observer)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Register the View as an Observer with the Controller
        this.controller.addStatusListener(this);

        // --- Component Setup ---

        // Strategy Selector
        this.strategySelector = new JComboBox<>(availableStrategies.toArray(new GenerationStrategy[0]));
        this.strategySelector.setRenderer(new StrategyRenderer());
        this.strategySelector.setSelectedItem(controller.getCurrentStrategy());

        // Setup text areas
        inputArea.setLineWrap(true);
        inputArea.setBorder(BorderFactory.createTitledBorder("Your Input Prompt:"));
        resultArea.setLineWrap(true);
        resultArea.setEditable(false);
        resultArea.setBorder(BorderFactory.createTitledBorder("AI Generated Output:"));

        // Initialize Cancel button state
        cancelButton.setEnabled(false);

        // --- Event Handling ---

        // Action: Generate Button (Delegates to Controller)
        generateButton.addActionListener(e -> {
            if (inputArea.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a prompt.", "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            controller.generateText(inputArea.getText());
        });

        // Action for Cancel Button (Delegates to Controller)
        cancelButton.addActionListener(e -> {
            controller.cancelGeneration();
        });


        // Action: Strategy Selector (Delegates to Controller)
        strategySelector.addActionListener(e -> {
            GenerationStrategy selected = (GenerationStrategy) strategySelector.getSelectedItem();
            if (selected != null) {
                controller.setStrategy(selected);
            }
        });

        // Setup Menu Bar for Save/Load
        setupMenuBar();

        // --- Layout Assembly ---

        // Top Panel: Mode Selector and Control Buttons
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controlPanel.add(new JLabel("Mode:"));
        controlPanel.add(strategySelector);
        controlPanel.add(generateButton);
        controlPanel.add(cancelButton);

        // Center Panel: Input and Output Areas
        JPanel textPanel = new JPanel(new GridLayout(1, 2, 10, 10));
        textPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        textPanel.add(new JScrollPane(inputArea));
        textPanel.add(new JScrollPane(resultArea));

        // Status Bar
        statusLabel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        statusLabel.setFont(statusLabel.getFont().deriveFont(Font.BOLD));

        // Main Frame Layout
        add(controlPanel, BorderLayout.NORTH);
        add(textPanel, BorderLayout.CENTER);
        add(statusLabel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
    }

    /**
     * Helper method to set up the menu bar for Save/Load functionality.
     */
    private void setupMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");

        JMenuItem saveItem = new JMenuItem("Save Session...");
        saveItem.addActionListener(e -> controller.saveSession());

        JMenuItem loadItem = new JMenuItem("Load Session...");
        loadItem.addActionListener(e -> controller.loadSession());

        fileMenu.add(saveItem);
        fileMenu.add(loadItem);
        fileMenu.addSeparator();

        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        menuBar.add(fileMenu);
        setJMenuBar(menuBar);
    }

    // --- Public Methods for Controller Access ---

    public void setResultText(String text) {
        resultArea.setText(text);
    }

    public void setInputText(String text) {
        inputArea.setText(text);
    }

    public void setStatus(String status) {
        statusLabel.setText(status);
    }

    // --- OBSERVER INTERFACE IMPLEMENTATION (Step 10) ---

    @Override
    public void generationStarted() {
        setStatus("Generating response using " + controller.getCurrentStrategy().getName() + "...");
        setResultText("...");
        setUIBusy(true);
    }

    @Override
    public void generationCompleted(String result) {
        setResultText(result);
        setStatus("Generation Complete.");
        setUIBusy(false);
    }

    @Override
    public void generationFailed(String errorMessage) {
        setResultText("--- ERROR ---");
        setStatus(errorMessage);
        setUIBusy(false);
    }

    /**
     * Private helper method to manage UI state (busy/idle) for non-blocking UI.
     */
    private void setUIBusy(boolean isBusy) {
        generateButton.setEnabled(!isBusy);
        cancelButton.setEnabled(isBusy);
        inputArea.setEnabled(!isBusy);
        strategySelector.setEnabled(!isBusy);
        // NOTE: The user is responsible for adding a JProgressBar/spinner here for visual feedback.
    }

    // Custom ListCellRenderer (uses GenerationStrategy interface)
    private class StrategyRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof GenerationStrategy) {
                setText(((GenerationStrategy) value).getName());
            }
            return this;
        }
    }
}